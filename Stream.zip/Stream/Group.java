public class Group {
    private final  String name;

    public  Group(String name) {
        this.name = name;
    }

    public String getName(){
        return name;
    }
}


