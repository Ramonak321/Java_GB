import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Stream stream1 = new Stream();
        Stream stream2 = new Stream();
        stream1.addGroup(new Group("Group1"));
        stream2.addGroup(new Group("Group2"));

        // Stream stream2 = new Stream();
        stream2.addGroup(new Group("Group3"));

        List<Stream> streams = new ArrayList<>();
        streams.add(stream1);
        streams.add(stream2);

        StreamService streamService = new StreamService();
        Controller controller = new Controller(streamService);

        System.out.println("soring: ");
        for (Stream stream : streams){
            for(Group group : stream){
                System.out.println(group.getName());
            }
        }
        controller.sortStreams(streams);
        System.out.println("sorted: ");
        for (Stream stream : streams){
            for (Group groups : stream){
                System.out.println(groups.getName());
            }
        }
    }
}
