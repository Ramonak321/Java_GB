public interface faceAutomat {
    public void getProduct();
}