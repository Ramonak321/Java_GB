public class HotDrinkAutomat implements faceAutomat {
    
    @Override

    public void getProduct() {
        //asdasdasdfasd
    }

    public HotDrinkTemp getProduct(String name, int value, int temp){
        return new HotDrinkTemp(name, value, temp);
    }
}
