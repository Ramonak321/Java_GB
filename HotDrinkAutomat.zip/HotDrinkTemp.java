public class HotDrinkTemp extends HotDrink {
    private int temp;
    public HotDrinkTemp(String name, int value, int temp){
        super(name, value);
        this.temp = temp;
    }

    public int getTemp(){
        return temp;
    }

    public void setTemp(int temp){
        this.temp = temp;
    }

}