public class main {
    public static void main (String[] args){
        HotDrinkTemp hotDrink1 = new HotDrinkTemp("coffee", 1,  100);
        HotDrinkTemp hotDrink2 = new HotDrinkTemp("tea", 2,  100);
        HotDrinkTemp hotDrink3 = new HotDrinkTemp("chocolat", 2,  50);
    
        HotDrinkAutomat hotDrinkAutomat = new HotDrinkAutomat();
        String product1 = HotDrinkTemp.getName();
        String product2 = HotDrinkTemp.getName();
        String product3 = HotDrinkTemp.getName();
    }

    System.Out.println(product1, product2, product3);
}